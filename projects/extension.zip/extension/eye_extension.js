// Lauren's eye safety extension
console.log("working");
// setInterval(function()
setTimeout(function() { alert("You've been looking at your screen for too long!"); }, 1800000);
setTimeout(function() { alert("It's been another 30 minutes, go look away now!"); }, 3600000);
setTimeout(function() { alert("You've been on your computer for 90 minutes! Time to move!"); }, 5400000);
setTimeout(function() { alert("I bet this pop up is getting on your nerves"); }, 7200000);
setTimeout(function() { alert("c'mon it's time to get up dude"); }, 9000000);
setTimeout(function() { alert("please, your eyes are going to dry out!"); }, 10800000);
setTimeout(function() { alert("I'm begging you, go outside"); }, 12600000);

setInterval(function() {
	var blur = document.createElement("div");
	blur.setAttribute("id", "blur_html");
	blur.style.width = "100vw";
	blur.style.height = "100vh";
	blur.style.position = "fixed";
	blur.style.left = "0px";
	blur.style.top = "0px";

	function make_dot() {
	  var dot = document.createElement("div");
	  dot.classList.add("dot");
	  document.body.appendChild(dot);
	  var random_number = (Math.random() * 100);
	  dot.style.height =  random_number + "px";
	  dot.style.width = random_number + "px";
	  dot.style.borderRadius = "50%";
	  dot.style.backgroundColor = "white";
	  dot.style.position = "absolute";
	  dot.style.left = (Math.random() * 2000) + "px";
	  dot.style.top = (Math.random() * 2000) + "px";
	  dot.style.animationName = "popup";
	}

	for (var i = 0; i < 500; i++) {
	  make_dot();
	};

	document.body.appendChild(blur);

	blur.style.backdropFilter = "blur(8px)";
	setTimeout(function(){ 
		var unblur = document.getElementById("blur_html");
		document.body.removeChild(unblur);
		console.log("unblurred"); 
	}, 20000);
}, 1800000);
